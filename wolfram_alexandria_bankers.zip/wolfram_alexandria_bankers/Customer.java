import java.util.Random;

class Customer implements Runnable {

    private Thread t;
    private String threadName = "default";
    private int numOfResources = Bank.NUM_OF_RESOURCES;
    private int[] maxDemandDemand;
    private int customerNum;

    Random rand = new Random();

    Bank theBank = new Bank();

    Customer(int custNum)
    {
        customerNum = custNum;
        threadName = Integer.toString(custNum);
    }
    public void run()
    {
        int[] resource = new int[numOfResources];
        for(int i = 0; i < theBank.NUM_OF_RESOURCES; i++)
        {
            resource[i] = theBank.allocated[customerNum][i];
        }
        theBank.requestResources(customerNum, resource);
        int sleep = rand.nextInt(5) + 1;
        try
        {
            Thread.sleep(sleep*100);
        }
        catch (InterruptedException ioe)
        {}
        theBank.releaseResources(customerNum,resource);
    }
    public void start()
    {
        if (t==null)
        {
            t = new Thread(this,threadName);
            t.start();
        }
    }

}