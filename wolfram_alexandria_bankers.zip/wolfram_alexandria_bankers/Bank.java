import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Bank {


    public static int COUNT = 5; //number of eventual customer threads
    public static int NUM_OF_RESOURCES = 3;

    public static int[] available = new int[NUM_OF_RESOURCES]; //current resources available
    public static int[][] allocated = new int[COUNT][NUM_OF_RESOURCES]; //how many currently held
    public static int[][] need = new int[COUNT][NUM_OF_RESOURCES];  //how many more needed
    public static int[][] maxDemand = new int[COUNT][NUM_OF_RESOURCES]; //how many total until completed

    public static int end = 5; //counter so that the process will end when all threads complete
    public static ArrayList<Integer> doneThreads = new ArrayList<Integer>(COUNT);
    public static java.util.Random rand = new Random();


    public static boolean check(int custNum, int[] request, int[]availCopy){
        boolean safe = true;

        for (int i = 0; i < NUM_OF_RESOURCES; i++)
        {
            if (request[i] > need[custNum][i]/* && (request[i] < maxDemand[custNum][i])*/) { //request greater than or equal to the than need
                safe = false;
            }
            if (safe && request[i] > availCopy[i]) {
                safe = false;
            }
        }

        return safe;
    }

    public static boolean safeState(int[][] demandC, int[] requestC, int[] availC, int[][] allocC, int[][] needCopyC, int custNumC)
    {
        int[][] demand = demandC;
        int[] request =requestC;
        int[] avail = availC;
        int[][] alloc = allocC;
        int[][] needCopy = needCopyC;
        int custNum = custNumC;

        ArrayList<Integer> holder = doneThreads;
        if (need[custNum] == request)
        {
            for (int i = 0; i < NUM_OF_RESOURCES; i++) {
                avail[i] += request[i];
                needCopy[custNum][i] = 0;
                alloc[custNum][i] = 0;
                demand[custNum][i] = 0;
            }
            holder.add(custNum);

        }
        else {//finds out the new availiable values and if it satifies all needed then release values
            for (int i = 0; i < NUM_OF_RESOURCES; i++) {
                avail[i] -= request[i];
                alloc[custNum][i] += request[i];
                needCopy[custNum][i] -= request[i];
                demand[custNum][i] -= request[i];
            }
        }
        int count;
        for (int i = 0; i < COUNT; i++) {
            count = 0;
            if (!holder.contains(i)) {
                //check if any other resource can be allocated with the new avaliable values
                    for (int j = 0; j < NUM_OF_RESOURCES; j++) {
                        if(needCopy[i][j] <= avail[j])
                            count++;
                    }
                    if(count == NUM_OF_RESOURCES)
                    {
                        return true;
                    }

            }
        }
      return false;
    }

    public static boolean requestResources(int custNum, int[] request)
    {

        boolean safe = check(custNum,request,available) && safeState(maxDemand,request,available,allocated,need,custNum);



        if (safe) {
           // System.out.println("Going through safe loop!");
            for (int i = 0; i < NUM_OF_RESOURCES; i++) {
                //available[i] -= request[i];
                //allocated[custNum][i] += request[i];
              //  need[custNum][i] -= request[i];
                for (int j = 0; j < request[i]; j++) {
                    Customer customer = new Customer(custNum);
                    customer.start();
                }
            }
            int counter = 0;
            int[] holder = new int[NUM_OF_RESOURCES];
            for(int i = 0; i < NUM_OF_RESOURCES; i++)
            {
                holder[i] = allocated[custNum][i];
            }
            for (int i = 0; i < NUM_OF_RESOURCES; i++) {
                if (need[custNum][i] == 0) {
                    counter++;
                }
            }
            if(counter == NUM_OF_RESOURCES)
            {
                if (!doneThreads.contains(custNum))
                {
                    doneThreads.add(custNum);
                    releaseResources(custNum,holder);
                    inactivateCustomer(custNum);
                }



            }
            return true;
        }

        return false;
    }

    public static int releaseResources(int custNum, int[] release)
    {
        int counter = 0;
        for (int i = 0; i < NUM_OF_RESOURCES; i++) {
            if (need[custNum][i] == 0) {
                counter++;
            }
        }
        int[] holder = new int[NUM_OF_RESOURCES];
        for(int i = 0; i < NUM_OF_RESOURCES; i++)
        {
            holder[i] = allocated[custNum][i];
        }
        if(counter == NUM_OF_RESOURCES)
        {
            if (!doneThreads.contains(custNum))
            {
                for(int i = 0; i < NUM_OF_RESOURCES; i++)
                {

                    //System.out.println("Releasing resources!");
                    available[i] += release[i];
                    need[custNum][i] += release[i];
                    allocated[custNum][i] -= release[i];
                }

            }
        }


        return 0;
    }

    public static void getState()
    {
// outputs available, allocation, maxDemand, and need matrices
        System.out.println("AVAILABLE: \n" + Arrays.toString(available) + "\nALLOCATED: \n" + Arrays.deepToString(allocated).replace("], ", "]\n") +
                "\nMAX DEMAND: \n" + Arrays.deepToString(maxDemand).replace("], ", "]\n") +
                "\nNEED: \n" + Arrays.deepToString(need).replace("], ", "]\n"));
    }

    public int[] getAllocated(int threadNum)
    {

        int[] holder = new int[NUM_OF_RESOURCES];
        for(int i = 0; i < NUM_OF_RESOURCES; i++)
        {
            holder[i] = allocated[threadNum][i];
        }
        return holder;
    }

    public static void inactivateCustomer(int threadNum)
    {

        //System.out.println("Inactivate Customer!");
        for(int i = 0; i < NUM_OF_RESOURCES; i++)
        {
            maxDemand[threadNum][i] = 0;
            allocated[threadNum][i] = 0;
            need[threadNum][i] = 0;
        }
        end--;
    }
}
